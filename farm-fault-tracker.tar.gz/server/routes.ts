import type { Express } from "express";
import { createServer, type Server } from "http";
import { WebSocketServer, WebSocket } from "ws";
import { storage } from "./storage";
import { setupAuth, isAuthenticated } from "./replitAuth";
import {
  insertFaultSchema,
  updateFaultSchema,
  insertCommentSchema,
  insertFarmSchema,
  insertMachineSchema,
} from "@shared/schema";

export async function registerRoutes(app: Express): Promise<Server> {
  // Auth middleware
  await setupAuth(app);

  // Auth routes
  app.get('/api/auth/user', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      res.json(user);
    } catch (error) {
      console.error("Error fetching user:", error);
      res.status(500).json({ message: "Failed to fetch user" });
    }
  });

  // Dashboard routes
  app.get('/api/dashboard/stats', isAuthenticated, async (req, res) => {
    try {
      const stats = await storage.getDashboardStats();
      res.json(stats);
    } catch (error) {
      console.error("Error fetching dashboard stats:", error);
      res.status(500).json({ message: "Failed to fetch dashboard stats" });
    }
  });

  app.get('/api/dashboard/activity', isAuthenticated, async (req, res) => {
    try {
      const activity = await storage.getRecentActivity();
      res.json(activity);
    } catch (error) {
      console.error("Error fetching recent activity:", error);
      res.status(500).json({ message: "Failed to fetch recent activity" });
    }
  });

  app.get('/api/dashboard/deadlines', isAuthenticated, async (req, res) => {
    try {
      const deadlines = await storage.getUpcomingDeadlines();
      res.json(deadlines);
    } catch (error) {
      console.error("Error fetching upcoming deadlines:", error);
      res.status(500).json({ message: "Failed to fetch upcoming deadlines" });
    }
  });

  // Farm routes
  app.get('/api/farms', isAuthenticated, async (req, res) => {
    try {
      const farms = await storage.getFarms();
      res.json(farms);
    } catch (error) {
      console.error("Error fetching farms:", error);
      res.status(500).json({ message: "Failed to fetch farms" });
    }
  });

  app.post('/api/farms', isAuthenticated, async (req, res) => {
    try {
      const farmData = insertFarmSchema.parse(req.body);
      const farm = await storage.createFarm(farmData);
      res.status(201).json(farm);
    } catch (error) {
      console.error("Error creating farm:", error);
      res.status(400).json({ message: "Failed to create farm" });
    }
  });

  // Machine routes
  app.get('/api/machines', isAuthenticated, async (req, res) => {
    try {
      const farmId = req.query.farmId ? parseInt(req.query.farmId as string) : undefined;
      const machines = await storage.getMachines(farmId);
      res.json(machines);
    } catch (error) {
      console.error("Error fetching machines:", error);
      res.status(500).json({ message: "Failed to fetch machines" });
    }
  });

  app.post('/api/machines', isAuthenticated, async (req, res) => {
    try {
      const machineData = insertMachineSchema.parse(req.body);
      const machine = await storage.createMachine(machineData);
      res.status(201).json(machine);
    } catch (error) {
      console.error("Error creating machine:", error);
      res.status(400).json({ message: "Failed to create machine" });
    }
  });

  // Fault routes
  app.get('/api/faults', isAuthenticated, async (req, res) => {
    try {
      const filters = {
        status: req.query.status as string,
        priority: req.query.priority as string,
        farmId: req.query.farmId ? parseInt(req.query.farmId as string) : undefined,
        machineId: req.query.machineId ? parseInt(req.query.machineId as string) : undefined,
        assignedToId: req.query.assignedToId as string,
        search: req.query.search as string,
      };
      
      // Remove undefined values
      Object.keys(filters).forEach(key => 
        filters[key as keyof typeof filters] === undefined && delete filters[key as keyof typeof filters]
      );

      const faults = await storage.getFaults(filters);
      res.json(faults);
    } catch (error) {
      console.error("Error fetching faults:", error);
      res.status(500).json({ message: "Failed to fetch faults" });
    }
  });

  app.get('/api/faults/:id', isAuthenticated, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const fault = await storage.getFault(id);
      if (!fault) {
        return res.status(404).json({ message: "Fault not found" });
      }
      res.json(fault);
    } catch (error) {
      console.error("Error fetching fault:", error);
      res.status(500).json({ message: "Failed to fetch fault" });
    }
  });

  app.post('/api/faults', isAuthenticated, async (req: any, res) => {
    try {
      const faultData = insertFaultSchema.parse({
        ...req.body,
        reportedById: req.user.claims.sub,
      });
      const fault = await storage.createFault(faultData);
      
      // Broadcast to all connected WebSocket clients
      broadcastToClients('fault_created', fault);
      
      res.status(201).json(fault);
    } catch (error) {
      console.error("Error creating fault:", error);
      res.status(400).json({ message: "Failed to create fault" });
    }
  });

  app.patch('/api/faults/:id', isAuthenticated, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const faultData = updateFaultSchema.parse({ ...req.body, id });
      
      if (faultData.status === 'resolved' && !faultData.resolvedAt) {
        faultData.resolvedAt = new Date();
      }
      
      const fault = await storage.updateFault(faultData);
      
      // Broadcast to all connected WebSocket clients
      broadcastToClients('fault_updated', fault);
      
      res.json(fault);
    } catch (error) {
      console.error("Error updating fault:", error);
      res.status(400).json({ message: "Failed to update fault" });
    }
  });

  app.delete('/api/faults/:id', isAuthenticated, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      await storage.deleteFault(id);
      
      // Broadcast to all connected WebSocket clients
      broadcastToClients('fault_deleted', { id });
      
      res.status(204).send();
    } catch (error) {
      console.error("Error deleting fault:", error);
      res.status(500).json({ message: "Failed to delete fault" });
    }
  });

  // Comment routes
  app.post('/api/faults/:faultId/comments', isAuthenticated, async (req: any, res) => {
    try {
      const faultId = parseInt(req.params.faultId);
      const commentData = insertCommentSchema.parse({
        ...req.body,
        faultId,
        userId: req.user.claims.sub,
      });
      const comment = await storage.createComment(commentData);
      
      // Broadcast to all connected WebSocket clients
      broadcastToClients('comment_created', { faultId, comment });
      
      res.status(201).json(comment);
    } catch (error) {
      console.error("Error creating comment:", error);
      res.status(400).json({ message: "Failed to create comment" });
    }
  });

  const httpServer = createServer(app);

  // WebSocket setup
  const wss = new WebSocketServer({ server: httpServer, path: '/ws' });
  const clients = new Set<WebSocket>();

  wss.on('connection', (ws) => {
    clients.add(ws);
    console.log('WebSocket client connected');

    ws.on('close', () => {
      clients.delete(ws);
      console.log('WebSocket client disconnected');
    });

    ws.on('error', (error) => {
      console.error('WebSocket error:', error);
      clients.delete(ws);
    });
  });

  function broadcastToClients(type: string, data: any) {
    const message = JSON.stringify({ type, data });
    clients.forEach((client) => {
      if (client.readyState === WebSocket.OPEN) {
        client.send(message);
      }
    });
  }

  return httpServer;
}

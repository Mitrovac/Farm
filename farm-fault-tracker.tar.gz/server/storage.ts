import {
  users,
  farms,
  machines,
  faults,
  comments,
  type User,
  type UpsertUser,
  type Farm,
  type InsertFarm,
  type Machine,
  type InsertMachine,
  type Fault,
  type InsertFault,
  type UpdateFault,
  type Comment,
  type InsertComment,
  type FaultWithRelations,
  type MachineWithFarm,
  type FarmWithMachines,
} from "@shared/schema";
import { db } from "./db";
import { eq, desc, and, or, like, isNull, isNotNull } from "drizzle-orm";

export interface IStorage {
  // User operations (required for Replit Auth)
  getUser(id: string): Promise<User | undefined>;
  upsertUser(user: UpsertUser): Promise<User>;
  
  // Farm operations
  getFarms(): Promise<FarmWithMachines[]>;
  createFarm(farm: InsertFarm): Promise<Farm>;
  
  // Machine operations
  getMachines(farmId?: number): Promise<MachineWithFarm[]>;
  createMachine(machine: InsertMachine): Promise<Machine>;
  
  // Fault operations
  getFaults(filters?: {
    status?: string;
    priority?: string;
    farmId?: number;
    machineId?: number;
    assignedToId?: string;
    search?: string;
  }): Promise<FaultWithRelations[]>;
  getFault(id: number): Promise<FaultWithRelations | undefined>;
  createFault(fault: InsertFault): Promise<Fault>;
  updateFault(fault: UpdateFault): Promise<Fault>;
  deleteFault(id: number): Promise<void>;
  
  // Comment operations
  createComment(comment: InsertComment): Promise<Comment>;
  
  // Dashboard operations
  getDashboardStats(): Promise<{
    totalFaults: number;
    openFaults: number;
    inProgressFaults: number;
    resolvedFaults: number;
  }>;
  getRecentActivity(): Promise<any[]>;
  getUpcomingDeadlines(): Promise<FaultWithRelations[]>;
}

export class DatabaseStorage implements IStorage {
  // User operations
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async upsertUser(userData: UpsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(userData)
      .onConflictDoUpdate({
        target: users.id,
        set: {
          ...userData,
          updatedAt: new Date(),
        },
      })
      .returning();
    return user;
  }

  // Farm operations
  async getFarms(): Promise<FarmWithMachines[]> {
    return await db.query.farms.findMany({
      with: {
        machines: true,
      },
    });
  }

  async createFarm(farm: InsertFarm): Promise<Farm> {
    const [newFarm] = await db.insert(farms).values(farm).returning();
    return newFarm;
  }

  // Machine operations
  async getMachines(farmId?: number): Promise<MachineWithFarm[]> {
    const whereClause = farmId ? eq(machines.farmId, farmId) : undefined;
    
    return await db.query.machines.findMany({
      where: whereClause,
      with: {
        farm: true,
      },
    });
  }

  async createMachine(machine: InsertMachine): Promise<Machine> {
    const [newMachine] = await db.insert(machines).values(machine).returning();
    return newMachine;
  }

  // Fault operations
  async getFaults(filters?: {
    status?: string;
    priority?: string;
    farmId?: number;
    machineId?: number;
    assignedToId?: string;
    search?: string;
  }): Promise<FaultWithRelations[]> {
    let whereConditions = [];

    if (filters?.status) {
      whereConditions.push(eq(faults.status, filters.status));
    }
    if (filters?.priority) {
      whereConditions.push(eq(faults.priority, filters.priority));
    }
    if (filters?.machineId) {
      whereConditions.push(eq(faults.machineId, filters.machineId));
    }
    if (filters?.assignedToId) {
      whereConditions.push(eq(faults.assignedToId, filters.assignedToId));
    }
    if (filters?.search) {
      whereConditions.push(
        or(
          like(faults.title, `%${filters.search}%`),
          like(faults.description, `%${filters.search}%`)
        )
      );
    }

    const results = await db.query.faults.findMany({
      where: whereConditions.length > 0 ? and(...whereConditions) : undefined,
      with: {
        machine: {
          with: {
            farm: true,
          },
        },
        reportedBy: true,
        assignedTo: true,
        comments: {
          with: {
            user: true,
          },
          orderBy: desc(comments.createdAt),
        },
      },
      orderBy: desc(faults.createdAt),
    });

    return results.map(fault => ({
      ...fault,
      assignedTo: fault.assignedTo || undefined,
    })) as FaultWithRelations[];
  }

  async getFault(id: number): Promise<FaultWithRelations | undefined> {
    const result = await db.query.faults.findFirst({
      where: eq(faults.id, id),
      with: {
        machine: {
          with: {
            farm: true,
          },
        },
        reportedBy: true,
        assignedTo: true,
        comments: {
          with: {
            user: true,
          },
          orderBy: desc(comments.createdAt),
        },
      },
    });

    if (!result) return undefined;

    return {
      ...result,
      assignedTo: result.assignedTo || undefined,
    } as FaultWithRelations;
  }

  async createFault(fault: InsertFault): Promise<Fault> {
    const [newFault] = await db.insert(faults).values(fault).returning();
    return newFault;
  }

  async updateFault(fault: UpdateFault): Promise<Fault> {
    const { id, ...updateData } = fault;
    const [updatedFault] = await db
      .update(faults)
      .set({ ...updateData, updatedAt: new Date() })
      .where(eq(faults.id, id))
      .returning();
    return updatedFault;
  }

  async deleteFault(id: number): Promise<void> {
    await db.delete(faults).where(eq(faults.id, id));
  }

  // Comment operations
  async createComment(comment: InsertComment): Promise<Comment> {
    const [newComment] = await db.insert(comments).values(comment).returning();
    return newComment;
  }

  // Dashboard operations
  async getDashboardStats(): Promise<{
    totalFaults: number;
    openFaults: number;
    inProgressFaults: number;
    resolvedFaults: number;
  }> {
    const allFaults = await db.select().from(faults);
    
    return {
      totalFaults: allFaults.length,
      openFaults: allFaults.filter(f => f.status === 'open').length,
      inProgressFaults: allFaults.filter(f => f.status === 'in_progress').length,
      resolvedFaults: allFaults.filter(f => f.status === 'resolved').length,
    };
  }

  async getRecentActivity(): Promise<any[]> {
    const recentComments = await db.query.comments.findMany({
      with: {
        user: true,
        fault: true,
      },
      orderBy: desc(comments.createdAt),
      limit: 10,
    });

    return recentComments.map(comment => ({
      type: 'comment',
      user: comment.user,
      fault: comment.fault,
      createdAt: comment.createdAt,
    }));
  }

  async getUpcomingDeadlines(): Promise<FaultWithRelations[]> {
    const results = await db.query.faults.findMany({
      where: and(
        isNotNull(faults.dueDate),
        or(
          eq(faults.status, 'open'),
          eq(faults.status, 'in_progress')
        )
      ),
      with: {
        machine: {
          with: {
            farm: true,
          },
        },
        reportedBy: true,
        assignedTo: true,
        comments: {
          with: {
            user: true,
          },
        },
      },
      orderBy: faults.dueDate,
      limit: 10,
    });

    return results.map(fault => ({
      ...fault,
      assignedTo: fault.assignedTo || undefined,
    })) as FaultWithRelations[];
  }
}

export const storage = new DatabaseStorage();

import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Wrench, Users, Calendar, BarChart3, Globe } from "lucide-react";
import { t, toggleLanguage, getCurrentLanguage } from "@/lib/translations";

export default function Landing() {
  return (
    <div className="min-h-screen bg-material-background">
      {/* Header */}
      <header className="bg-material-blue text-white shadow-lg">
        <div className="container mx-auto px-4 py-6 flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <Wrench className="h-8 w-8" />
            <h1 className="text-2xl font-medium">{t('Farm Fault Tracker')}</h1>
          </div>
          <div className="flex items-center space-x-4">
            <Button
              variant="ghost"
              size="sm"
              onClick={toggleLanguage}
              className="text-white hover:bg-white hover:bg-opacity-10"
            >
              <Globe className="h-4 w-4 mr-2" />
              {getCurrentLanguage() === 'hr' ? 'EN' : 'HR'}
            </Button>
            <Button 
              onClick={() => window.location.href = '/api/login'}
              className="bg-white text-material-blue hover:bg-gray-100"
            >
              {t('Sign In')}
            </Button>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="py-20 px-4">
        <div className="container mx-auto text-center">
          <h2 className="text-4xl font-bold text-gray-900 mb-6">
            {t('Track and Manage Machine Faults Across All Your Farms')}
          </h2>
          <p className="text-xl text-gray-600 mb-8 max-w-3xl mx-auto">
            {t('A real-time fault tracking system designed for agricultural operations.')} {t('Manage machine issues across multiple farms with team collaboration and deadline management.')}
          </p>
          <Button 
            onClick={() => window.location.href = '/api/login'}
            className="bg-material-blue hover:bg-material-blue-dark text-white px-8 py-3 text-lg"
          >
            {t('Get Started')}
          </Button>
        </div>
      </section>

      {/* Features */}
      <section className="py-16 px-4 bg-white">
        <div className="container mx-auto">
          <h3 className="text-3xl font-bold text-center text-gray-900 mb-12">
            {t('Everything You Need to Manage Farm Equipment')}
          </h3>
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            <Card>
              <CardHeader className="text-center">
                <Wrench className="h-12 w-12 text-material-blue mx-auto mb-4" />
                <CardTitle>{t('Fault Tracking')}</CardTitle>
              </CardHeader>
              <CardContent>
                <CardDescription>
                  {t('Create, assign, and track machine faults with detailed status updates and priority levels.')}
                </CardDescription>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="text-center">
                <Users className="h-12 w-12 text-material-blue mx-auto mb-4" />
                <CardTitle>{t('Team Collaboration')}</CardTitle>
              </CardHeader>
              <CardContent>
                <CardDescription>
                  {t('Real-time updates and comments keep your entire team informed on repair progress.')}
                </CardDescription>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="text-center">
                <Calendar className="h-12 w-12 text-material-blue mx-auto mb-4" />
                <CardTitle>{t('Deadline Management')}</CardTitle>
              </CardHeader>
              <CardContent>
                <CardDescription>
                  {t('Set and track repair deadlines to ensure critical equipment stays operational.')}
                </CardDescription>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="text-center">
                <BarChart3 className="h-12 w-12 text-material-blue mx-auto mb-4" />
                <CardTitle>{t('Analytics & Reports')}</CardTitle>
              </CardHeader>
              <CardContent>
                <CardDescription>
                  {t('Dashboard insights and reporting to optimize your maintenance operations.')}
                </CardDescription>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Multi-Farm Support */}
      <section className="py-16 px-4">
        <div className="container mx-auto text-center">
          <h3 className="text-3xl font-bold text-gray-900 mb-6">
            {t('Designed for Multi-Farm Operations')}
          </h3>
          <p className="text-lg text-gray-600 mb-8 max-w-2xl mx-auto">
            {t('Manage equipment across all 7 farms from a single dashboard.')} {t('Get farm-specific insights and cross-farm visibility into your entire operation.')}
          </p>
          <div className="grid md:grid-cols-3 gap-8 max-w-4xl mx-auto">
            <div className="text-center">
              <div className="bg-material-blue text-white w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4 text-2xl font-bold">
                7
              </div>
              <h4 className="font-semibold text-gray-900 mb-2">{t('Farms Supported')}</h4>
              <p className="text-gray-600">{t('Manage equipment across multiple farm locations')}</p>
            </div>
            <div className="text-center">
              <div className="bg-material-success text-white w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4 text-2xl font-bold">
                ∞
              </div>
              <h4 className="font-semibold text-gray-900 mb-2">{t('Unlimited Machines')}</h4>
              <p className="text-gray-600">{t('Track as many machines as you need per farm')}</p>
            </div>
            <div className="text-center">
              <div className="bg-material-warning text-white w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4 text-2xl font-bold">
                24/7
              </div>
              <h4 className="font-semibold text-gray-900 mb-2">{t('Real-time Updates')}</h4>
              <p className="text-gray-600">{t('Stay informed with live status updates')}</p>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-8 px-4">
        <div className="container mx-auto text-center">
          <div className="flex items-center justify-center space-x-4 mb-4">
            <Wrench className="h-6 w-6" />
            <span className="text-lg font-medium">{t('Farm Fault Tracker')}</span>
          </div>
          <p className="text-gray-400">
            {t('Streamline your agricultural equipment maintenance operations')}
          </p>
        </div>
      </footer>
    </div>
  );
}

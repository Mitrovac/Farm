import { useAuth } from "@/hooks/useAuth";
import { useEffect, useState } from "react";
import { useToast } from "@/hooks/use-toast";
import AppHeader from "@/components/layout/AppHeader";
import Sidebar from "@/components/layout/Sidebar";
import FaultTable from "@/components/faults/FaultTable";
import FaultForm from "@/components/faults/FaultForm";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Plus, Search, Filter } from "lucide-react";
import { useQuery } from "@tanstack/react-query";
import { t } from "@/lib/translations";

export default function Faults() {
  const { toast } = useToast();
  const { isAuthenticated, isLoading } = useAuth();
  const [showFaultForm, setShowFaultForm] = useState(false);
  const [filters, setFilters] = useState({
    status: '',
    priority: '',
    farmId: '',
    search: '',
  });

  // Redirect to home if not authenticated
  useEffect(() => {
    if (!isLoading && !isAuthenticated) {
      toast({
        title: "Unauthorized",
        description: "You are logged out. Logging in again...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
      return;
    }
  }, [isAuthenticated, isLoading, toast]);

  const { data: farms } = useQuery({
    queryKey: ["/api/farms"],
    enabled: isAuthenticated,
  });

  if (isLoading || !isAuthenticated) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-material-blue"></div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-material-background">
      <AppHeader />
      
      <div className="flex">
        <Sidebar />
        
        <main className="flex-1 p-6">
          {/* Page Header */}
          <div className="mb-6 flex items-center justify-between">
            <div>
              <h2 className="text-2xl font-medium text-gray-900">{t('All Faults')}</h2>
              <p className="text-gray-600 mt-1">{t('Manage and track all machine faults across your farms.')}</p>
            </div>
            <Dialog open={showFaultForm} onOpenChange={setShowFaultForm}>
              <DialogTrigger asChild>
                <Button className="bg-material-blue hover:bg-material-blue-dark text-white flex items-center space-x-2 shadow-md">
                  <Plus className="h-4 w-4" />
                  <span>{t('Report Fault')}</span>
                </Button>
              </DialogTrigger>
              <DialogContent className="max-w-2xl">
                <DialogHeader>
                  <DialogTitle>{t('Report New Fault')}</DialogTitle>
                </DialogHeader>
                <FaultForm onSuccess={() => setShowFaultForm(false)} />
              </DialogContent>
            </Dialog>
          </div>

          {/* Filters */}
          <div className="mb-6 bg-white rounded-lg shadow-md p-4">
            <div className="flex items-center space-x-4">
              <div className="flex items-center space-x-2 flex-1">
                <Search className="h-4 w-4 text-gray-400" />
                <Input
                  placeholder="Search faults..."
                  value={filters.search}
                  onChange={(e) => setFilters({ ...filters, search: e.target.value })}
                  className="border-0 shadow-none focus-visible:ring-0"
                />
              </div>
              
              <Select value={filters.status} onValueChange={(value) => setFilters({ ...filters, status: value })}>
                <SelectTrigger className="w-32">
                  <SelectValue placeholder="Status" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="">All Status</SelectItem>
                  <SelectItem value="open">Open</SelectItem>
                  <SelectItem value="in_progress">In Progress</SelectItem>
                  <SelectItem value="resolved">Resolved</SelectItem>
                  <SelectItem value="closed">Closed</SelectItem>
                </SelectContent>
              </Select>

              <Select value={filters.priority} onValueChange={(value) => setFilters({ ...filters, priority: value })}>
                <SelectTrigger className="w-32">
                  <SelectValue placeholder="Priority" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="">All Priority</SelectItem>
                  <SelectItem value="low">Low</SelectItem>
                  <SelectItem value="medium">Medium</SelectItem>
                  <SelectItem value="high">High</SelectItem>
                  <SelectItem value="critical">Critical</SelectItem>
                </SelectContent>
              </Select>

              <Select value={filters.farmId} onValueChange={(value) => setFilters({ ...filters, farmId: value })}>
                <SelectTrigger className="w-40">
                  <SelectValue placeholder="Farm" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="">All Farms</SelectItem>
                  {farms?.map((farm: any) => (
                    <SelectItem key={farm.id} value={farm.id.toString()}>
                      {farm.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>

              <Button
                variant="outline"
                onClick={() => setFilters({ status: '', priority: '', farmId: '', search: '' })}
                className="px-3"
              >
                <Filter className="h-4 w-4" />
              </Button>
            </div>
          </div>

          {/* Faults Table */}
          <FaultTable filters={filters} showHeader={false} />
        </main>
      </div>
    </div>
  );
}

import { useAuth } from "@/hooks/useAuth";
import { useEffect } from "react";
import { useToast } from "@/hooks/use-toast";
import AppHeader from "@/components/layout/AppHeader";
import Sidebar from "@/components/layout/Sidebar";
import StatsCards from "@/components/dashboard/StatsCards";
import FaultTable from "@/components/faults/FaultTable";
import FarmStatusOverview from "@/components/dashboard/FarmStatusOverview";
import UpcomingDeadlines from "@/components/dashboard/UpcomingDeadlines";
import TeamActivity from "@/components/dashboard/TeamActivity";
import FaultForm from "@/components/faults/FaultForm";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Plus } from "lucide-react";
import { useState } from "react";
import { isUnauthorizedError } from "@/lib/authUtils";
import { t } from "@/lib/translations";

export default function Dashboard() {
  const { toast } = useToast();
  const { isAuthenticated, isLoading } = useAuth();
  const [showFaultForm, setShowFaultForm] = useState(false);

  // Redirect to home if not authenticated
  useEffect(() => {
    if (!isLoading && !isAuthenticated) {
      toast({
        title: t("Unauthorized"),
        description: t("You are logged out. Logging in again..."),
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
      return;
    }
  }, [isAuthenticated, isLoading, toast]);

  if (isLoading || !isAuthenticated) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-material-blue"></div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-material-background">
      <AppHeader />
      
      <div className="flex">
        <Sidebar />
        
        <main className="flex-1 p-6">
          {/* Dashboard Header */}
          <div className="mb-6 flex items-center justify-between">
            <div>
              <h2 className="text-2xl font-medium text-gray-900">{t('Dashboard')}</h2>
              <p className="text-gray-600 mt-1">{t('Welcome back! Here\'s what\'s happening with your farm equipment.')}</p>
            </div>
            <Dialog open={showFaultForm} onOpenChange={setShowFaultForm}>
              <DialogTrigger asChild>
                <Button className="bg-material-blue hover:bg-material-blue-dark text-white flex items-center space-x-2 shadow-md">
                  <Plus className="h-4 w-4" />
                  <span>{t('Report Fault')}</span>
                </Button>
              </DialogTrigger>
              <DialogContent className="max-w-2xl">
                <DialogHeader>
                  <DialogTitle>{t('Report New Fault')}</DialogTitle>
                </DialogHeader>
                <FaultForm onSuccess={() => setShowFaultForm(false)} />
              </DialogContent>
            </Dialog>
          </div>

          {/* Stats Cards */}
          <StatsCards />

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mt-8">
            {/* Recent Faults Table */}
            <div className="lg:col-span-2">
              <FaultTable limit={5} showHeader={true} />
            </div>

            {/* Right Sidebar Content */}
            <div className="space-y-6">
              <FarmStatusOverview />
              <UpcomingDeadlines />
              <TeamActivity />
            </div>
          </div>
        </main>
      </div>

      {/* Floating Action Button */}
      <Dialog open={showFaultForm} onOpenChange={setShowFaultForm}>
        <DialogTrigger asChild>
          <button className="fixed bottom-6 right-6 bg-material-blue hover:bg-material-blue-dark text-white w-14 h-14 rounded-full shadow-lg hover:shadow-xl transition-all duration-200 flex items-center justify-center">
            <Plus className="h-6 w-6" />
          </button>
        </DialogTrigger>
      </Dialog>
    </div>
  );
}

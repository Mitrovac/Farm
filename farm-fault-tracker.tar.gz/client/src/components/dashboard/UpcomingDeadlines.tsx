import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { format } from "date-fns";
import { Link } from "wouter";
import { t } from "@/lib/translations";

export default function UpcomingDeadlines() {
  const { data: deadlines, isLoading } = useQuery({
    queryKey: ["/api/dashboard/deadlines"],
  });

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case "critical":
      case "high":
        return "bg-material-error";
      case "medium":
        return "bg-material-warning";
      default:
        return "bg-material-success";
    }
  };

  const getTimeColor = (dueDate: string) => {
    const due = new Date(dueDate);
    const now = new Date();
    const diffDays = Math.ceil((due.getTime() - now.getTime()) / (1000 * 60 * 60 * 24));
    
    if (diffDays <= 1) return "text-material-error";
    if (diffDays <= 3) return "text-material-warning";
    return "text-gray-600";
  };

  if (isLoading) {
    return (
      <Card className="bg-white shadow-md">
        <CardHeader>
          <CardTitle className="text-lg font-medium text-gray-900">Upcoming Deadlines</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {[...Array(3)].map((_, i) => (
              <div key={i} className="animate-pulse flex items-start space-x-3">
                <div className="w-2 h-2 bg-gray-200 rounded-full mt-2"></div>
                <div className="flex-1 space-y-2">
                  <div className="h-4 bg-gray-200 rounded w-3/4"></div>
                  <div className="h-3 bg-gray-200 rounded w-1/2"></div>
                  <div className="h-3 bg-gray-200 rounded w-1/3"></div>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="bg-white shadow-md">
      <CardHeader>
        <CardTitle className="text-lg font-medium text-gray-900">Upcoming Deadlines</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {deadlines?.map((fault: any) => (
            <div key={fault.id} className="flex items-start space-x-3">
              <div className={`w-2 h-2 ${getPriorityColor(fault.priority)} rounded-full mt-2`}></div>
              <div className="flex-1">
                <p className="text-sm font-medium text-gray-900">
                  #{fault.id} - {fault.title}
                </p>
                <p className="text-xs text-gray-600">
                  {fault.machine.manufacturer} {fault.machine.model}
                </p>
                <p className={`text-xs font-medium ${getTimeColor(fault.dueDate)}`}>
                  Due: {format(new Date(fault.dueDate), "MMM dd, yyyy")}
                </p>
              </div>
            </div>
          ))}
          {(!deadlines || deadlines.length === 0) && (
            <div className="text-center py-4 text-gray-500">
              No upcoming deadlines
            </div>
          )}
        </div>
        {deadlines && deadlines.length > 0 && (
          <div className="mt-4 pt-4 border-t border-gray-200">
            <Link href="/faults">
              <a className="text-material-blue hover:text-material-blue-dark text-sm font-medium">
                View All Deadlines
              </a>
            </Link>
          </div>
        )}
      </CardContent>
    </Card>
  );
}

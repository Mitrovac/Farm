import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { formatDistanceToNow } from "date-fns";

export default function TeamActivity() {
  const { data: activities, isLoading } = useQuery({
    queryKey: ["/api/dashboard/activity"],
  });

  const getInitials = (firstName?: string, lastName?: string) => {
    if (!firstName && !lastName) return "U";
    return `${firstName?.[0] || ""}${lastName?.[0] || ""}`.toUpperCase();
  };

  const getDisplayName = (firstName?: string, lastName?: string, email?: string) => {
    if (firstName || lastName) {
      return `${firstName || ""} ${lastName || ""}`.trim();
    }
    return email?.split("@")[0] || "User";
  };

  if (isLoading) {
    return (
      <Card className="bg-white shadow-md">
        <CardHeader>
          <CardTitle className="text-lg font-medium text-gray-900">Recent Team Activity</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {[...Array(3)].map((_, i) => (
              <div key={i} className="animate-pulse flex items-start space-x-3">
                <div className="w-8 h-8 bg-gray-200 rounded-full"></div>
                <div className="flex-1 space-y-2">
                  <div className="h-4 bg-gray-200 rounded w-3/4"></div>
                  <div className="h-3 bg-gray-200 rounded w-1/3"></div>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="bg-white shadow-md">
      <CardHeader>
        <CardTitle className="text-lg font-medium text-gray-900">Recent Team Activity</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {activities?.map((activity: any, index: number) => (
            <div key={index} className="flex items-start space-x-3">
              <Avatar className="w-8 h-8">
                <AvatarImage src={activity.user?.profileImageUrl} />
                <AvatarFallback className="text-xs">
                  {getInitials(activity.user?.firstName, activity.user?.lastName)}
                </AvatarFallback>
              </Avatar>
              <div className="flex-1">
                <p className="text-sm text-gray-900">
                  <span className="font-medium">
                    {getDisplayName(activity.user?.firstName, activity.user?.lastName, activity.user?.email)}
                  </span>{" "}
                  commented on fault{" "}
                  <span className="text-material-blue font-medium">
                    #{activity.fault?.id}
                  </span>
                </p>
                <p className="text-xs text-gray-600">
                  {formatDistanceToNow(new Date(activity.createdAt), { addSuffix: true })}
                </p>
              </div>
            </div>
          ))}
          {(!activities || activities.length === 0) && (
            <div className="text-center py-4 text-gray-500">
              No recent activity
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
}

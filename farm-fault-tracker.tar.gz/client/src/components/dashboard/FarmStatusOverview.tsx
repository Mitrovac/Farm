import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

export default function FarmStatusOverview() {
  const { data: farms, isLoading } = useQuery({
    queryKey: ["/api/farms"],
  });

  const getStatusColor = (machineCount: number) => {
    if (machineCount >= 6) return "bg-material-error";
    if (machineCount >= 4) return "bg-material-warning";
    return "bg-material-success";
  };

  if (isLoading) {
    return (
      <Card className="bg-white shadow-md">
        <CardHeader>
          <CardTitle className="text-lg font-medium text-gray-900">Farm Status Overview</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {[...Array(5)].map((_, i) => (
              <div key={i} className="animate-pulse flex items-center justify-between">
                <div className="flex items-center space-x-3">
                  <div className="w-3 h-3 bg-gray-200 rounded-full"></div>
                  <div className="h-4 bg-gray-200 rounded w-32"></div>
                </div>
                <div className="h-4 bg-gray-200 rounded w-20"></div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="bg-white shadow-md">
      <CardHeader>
        <CardTitle className="text-lg font-medium text-gray-900">Farm Status Overview</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {farms?.map((farm: any) => (
            <div key={farm.id} className="flex items-center justify-between">
              <div className="flex items-center space-x-3">
                <div className={`w-3 h-3 ${getStatusColor(farm.machines?.length || 0)} rounded-full`}></div>
                <span className="text-sm font-medium text-gray-900">{farm.name}</span>
              </div>
              <span className="text-sm text-gray-600">
                {farm.machines?.length || 0} machines
              </span>
            </div>
          ))}
          {(!farms || farms.length === 0) && (
            <div className="text-center py-4 text-gray-500">
              No farms found
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
}

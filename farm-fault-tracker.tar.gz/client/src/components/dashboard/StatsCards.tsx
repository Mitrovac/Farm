import { useQuery } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { TriangleAlert, Clock, Wrench, Check } from "lucide-react";
import { t } from "@/lib/translations";

export default function StatsCards() {
  const { data: stats, isLoading } = useQuery({
    queryKey: ["/api/dashboard/stats"],
  });

  if (isLoading) {
    return (
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {[...Array(4)].map((_, i) => (
          <Card key={i} className="animate-pulse">
            <CardContent className="p-6">
              <div className="h-16 bg-gray-200 rounded"></div>
            </CardContent>
          </Card>
        ))}
      </div>
    );
  }

  const cards = [
    {
      title: t("Total Faults"),
      value: stats?.totalFaults || 0,
      icon: TriangleAlert,
      iconColor: "text-material-blue",
      bgColor: "bg-material-blue bg-opacity-10",
      change: "+12%",
      changeText: "from last week",
      changeColor: "text-green-500",
    },
    {
      title: "Open Faults",
      value: stats?.openFaults || 0,
      icon: Clock,
      iconColor: "text-material-error",
      bgColor: "bg-material-error bg-opacity-10",
      change: "-3",
      changeText: "from yesterday",
      changeColor: "text-red-500",
    },
    {
      title: "In Progress",
      value: stats?.inProgressFaults || 0,
      icon: Wrench,
      iconColor: "text-material-warning",
      bgColor: "bg-material-warning bg-opacity-10",
      change: "+2",
      changeText: "from yesterday",
      changeColor: "text-green-500",
    },
    {
      title: "Resolved",
      value: stats?.resolvedFaults || 0,
      icon: Check,
      iconColor: "text-material-success",
      bgColor: "bg-material-success bg-opacity-10",
      change: "+5",
      changeText: "this week",
      changeColor: "text-green-500",
    },
  ];

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
      {cards.map((card) => (
        <Card key={card.title} className="bg-white shadow-md">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-gray-600 text-sm font-medium">{card.title}</p>
                <p className="text-2xl font-bold text-gray-900">{card.value}</p>
              </div>
              <div className={`p-3 rounded-full ${card.bgColor}`}>
                <card.icon className={`h-5 w-5 ${card.iconColor}`} />
              </div>
            </div>
            <div className="mt-4 flex items-center">
              <span className={`text-sm font-medium ${card.changeColor}`}>
                {card.change}
              </span>
              <span className="text-gray-600 text-sm ml-2">{card.changeText}</span>
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  );
}

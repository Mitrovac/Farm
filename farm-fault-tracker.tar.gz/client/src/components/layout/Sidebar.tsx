import { Link, useLocation } from "wouter";
import { cn } from "@/lib/utils";
import { 
  BarChart3, 
  MapPin, 
  Settings, 
  Tractor, 
  TriangleAlert, 
  Users, 
  Gauge 
} from "lucide-react";
import { t } from "@/lib/translations";

const getNavigation = () => [
  { name: t("Dashboard"), href: "/", icon: Gauge },
  { name: t("All Faults"), href: "/faults", icon: TriangleAlert, badge: "12" },
  { name: t("Machines"), href: "/machines", icon: Tractor },
  { name: t("Farms"), href: "/farms", icon: MapPin },
  { name: t("Team"), href: "/team", icon: Users },
  { name: t("Reports"), href: "/reports", icon: BarChart3 },
  { name: t("Settings"), href: "/settings", icon: Settings },
];

export default function Sidebar() {
  const [location] = useLocation();
  const navigation = getNavigation();

  return (
    <aside className="w-64 bg-white shadow-lg min-h-screen">
      <nav className="p-4">
        <ul className="space-y-2">
          {navigation.map((item) => {
            const isActive = location === item.href;
            return (
              <li key={item.name}>
                <Link href={item.href}>
                  <a
                    className={cn(
                      "flex items-center justify-between p-3 rounded-lg transition-colors",
                      isActive
                        ? "bg-material-blue bg-opacity-10 text-material-blue font-medium"
                        : "hover:bg-gray-100 text-gray-700"
                    )}
                  >
                    <div className="flex items-center space-x-3">
                      <item.icon className="w-5 h-5" />
                      <span>{item.name}</span>
                    </div>
                    {item.badge && (
                      <span className="bg-material-error text-white text-xs px-2 py-1 rounded-full">
                        {item.badge}
                      </span>
                    )}
                  </a>
                </Link>
              </li>
            );
          })}
        </ul>
      </nav>
    </aside>
  );
}

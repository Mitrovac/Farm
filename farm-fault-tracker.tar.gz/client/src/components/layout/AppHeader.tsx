import { useAuth } from "@/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";
import { Bell, Wrench, Globe } from "lucide-react";
import { t, toggleLanguage, getCurrentLanguage } from "@/lib/translations";

export default function AppHeader() {
  const { user } = useAuth();

  const getInitials = (firstName?: string, lastName?: string) => {
    if (!firstName && !lastName) return "U";
    return `${firstName?.[0] || ""}${lastName?.[0] || ""}`.toUpperCase();
  };

  const getDisplayName = (firstName?: string, lastName?: string, email?: string) => {
    if (firstName || lastName) {
      return `${firstName || ""} ${lastName || ""}`.trim();
    }
    return email?.split("@")[0] || "User";
  };

  return (
    <header className="bg-material-blue text-white shadow-lg">
      <div className="container mx-auto px-4 py-4 flex items-center justify-between">
        <div className="flex items-center space-x-4">
          <Wrench className="h-6 w-6" />
          <h1 className="text-xl font-medium">{t('Farm Fault Tracker')}</h1>
        </div>
        
        <div className="flex items-center space-x-4">
          <Button
            variant="ghost"
            size="sm"
            onClick={toggleLanguage}
            className="hover:bg-white hover:bg-opacity-10 p-2 rounded transition-colors flex items-center space-x-1"
          >
            <Globe className="h-4 w-4" />
            <span className="text-xs">{getCurrentLanguage() === 'hr' ? 'EN' : 'HR'}</span>
          </Button>
          
          <Button 
            variant="ghost" 
            size="sm"
            className="hover:bg-white hover:bg-opacity-10 p-2 rounded-full transition-colors relative"
          >
            <Bell className="h-4 w-4" />
            <span className="bg-material-error text-xs rounded-full px-1 absolute -top-1 -right-1 min-w-[16px] h-4 flex items-center justify-center text-white">
              3
            </span>
          </Button>
          
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" className="flex items-center space-x-2 hover:bg-white hover:bg-opacity-10 p-2 rounded">
                <Avatar className="w-8 h-8">
                  <AvatarImage src={user?.profileImageUrl || ""} />
                  <AvatarFallback className="bg-white text-material-blue text-sm">
                    {getInitials(user?.firstName, user?.lastName)}
                  </AvatarFallback>
                </Avatar>
                <span className="text-sm font-medium">
                  {getDisplayName(user?.firstName, user?.lastName, user?.email)}
                </span>
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="w-48">
              <DropdownMenuItem onClick={() => window.location.href = "/api/logout"}>
                {t('Sign Out')}
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </div>
    </header>
  );
}

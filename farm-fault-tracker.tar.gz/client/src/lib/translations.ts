// Croatian translations for the Farm Fault Tracker application

export const translations = {
  // Navigation and layout
  'Farm Fault Tracker': 'Praćenje Kvarova Farme',
  'Dashboard': 'Kontrolna Ploča',
  'All Faults': 'Svi Kvarovi',
  'Machines': 'Strojevi',
  'Farms': 'Farme',
  'Team': 'Tim',
  'Reports': 'Izvještaji',
  'Settings': 'Postavke',
  'Sign In': 'Prijavi se',
  'Sign Out': 'Odjavi se',
  'Get Started': 'Počni',
  
  // Landing page
  'Track and Manage Machine Faults Across All Your Farms': 'Pratite i Upravljajte Kvarovima Strojeva na Svim Vašim Farmama',
  'A real-time fault tracking system designed for agricultural operations.': 'Sustav praćenja kvarova u stvarnom vremenu dizajniran za poljoprivredne operacije.',
  'Manage machine issues across multiple farms with team collaboration and deadline management.': 'Upravljajte problemima strojeva na više farmi uz timsku suradnju i upravljanje rokovima.',
  'Everything You Need to Manage Farm Equipment': 'Sve Što Trebate za Upravljanje Farmskim Strojevima',
  'Fault Tracking': 'Praćenje Kvarova',
  'Create, assign, and track machine faults with detailed status updates and priority levels.': 'Kreirajte, dodijelite i pratite kvarove strojeva s detaljnim ažuriranjima statusa i razinama prioriteta.',
  'Team Collaboration': 'Timska Suradnja',
  'Real-time updates and comments keep your entire team informed on repair progress.': 'Ažuriranja u stvarnom vremenu i komentari drže vaš cijeli tim informiranim o napretku popravaka.',
  'Deadline Management': 'Upravljanje Rokovima',
  'Set and track repair deadlines to ensure critical equipment stays operational.': 'Postavite i pratite rokove popravaka kako biste osigurali da kritična oprema ostane operativna.',
  'Analytics & Reports': 'Analitika i Izvještaji',
  'Dashboard insights and reporting to optimize your maintenance operations.': 'Uvidi kontrolne ploče i izvještavanje za optimizaciju vaših operacija održavanja.',
  'Designed for Multi-Farm Operations': 'Dizajnirano za Operacije na Više Farmi',
  'Manage equipment across all 7 farms from a single dashboard.': 'Upravljajte opremom na sve 7 farmi s jedne kontrolne ploče.',
  'Get farm-specific insights and cross-farm visibility into your entire operation.': 'Dobijte uvide specifične za farme i vidljivost preko farmi u cijelu vašu operaciju.',
  'Farms Supported': 'Podržane Farme',
  'Manage equipment across multiple farm locations': 'Upravljajte opremom na više lokacija farmi',
  'Unlimited Machines': 'Neograničeno Strojeva',
  'Track as many machines as you need per farm': 'Pratite koliko god strojeva trebate po farmi',
  'Real-time Updates': 'Ažuriranja u Stvarnom Vremenu',
  'Stay informed with live status updates': 'Ostanite informirani s ažuriranjima statusa uživo',
  'Streamline your agricultural equipment maintenance operations': 'Pojednostavite operacije održavanja vaše poljoprivredne opreme',
  
  // Dashboard
  'Welcome back! Here\'s what\'s happening with your farm equipment.': 'Dobro došli natrag! Evo što se događa s vašom farmskom opremom.',
  'Report Fault': 'Prijavi Kvar',
  'Report New Fault': 'Prijavi Novi Kvar',
  'Total Faults': 'Ukupno Kvarova',
  'Open Faults': 'Otvoreni Kvarovi',
  'In Progress': 'U Tijeku',
  'Resolved': 'Riješeno',
  'from last week': 'od prošlog tjedna',
  'from yesterday': 'od jučer',
  'this week': 'ovaj tjedan',
  'Farm Status Overview': 'Pregled Stanja Farmi',
  'Upcoming Deadlines': 'Nadolazeći Rokovi',
  'Recent Team Activity': 'Nedavna Aktivnost Tima',
  'Recent Faults': 'Nedavni Kvarovi',
  'View All': 'Prikaži Sve',
  'No farms found': 'Nema pronađenih farmi',
  'No upcoming deadlines': 'Nema nadolazećih rokova',
  'No recent activity': 'Nema nedavne aktivnosti',
  'View All Deadlines': 'Prikaži Sve Rokove',
  'machines': 'strojeva',
  'commented on fault': 'komentirao kvar',
  
  // Fault management
  'Manage and track all machine faults across your farms.': 'Upravljajte i pratite sve kvarove strojeva na vašim farmama.',
  'Search faults...': 'Pretraži kvarove...',
  'Status': 'Status',
  'Priority': 'Prioritet',
  'Farm': 'Farma',
  'All Status': 'Svi Statusi',
  'Open': 'Otvoren',
  'Closed': 'Zatvoren',
  'All Priority': 'Svi Prioriteti',
  'Low': 'Nizak',
  'Medium': 'Srednji',
  'High': 'Visok',
  'Critical': 'Kritičan',
  'All Farms': 'Sve Farme',
  'No faults found': 'Nema pronađenih kvarova',
  
  // Fault form
  'Title': 'Naslov',
  'Brief description of the fault': 'Kratki opis kvara',
  'Machine': 'Stroj',
  'Select Farm': 'Odaberi Farmu',
  'Select Machine': 'Odaberi Stroj',
  'Select Priority': 'Odaberi Prioritet',
  'Select Status': 'Odaberi Status',
  'Due Date (Optional)': 'Rok (Opcionalno)',
  'Pick a date': 'Odaberi datum',
  'Description': 'Opis',
  'Detailed description of the fault and any relevant information': 'Detaljni opis kvara i sve relevantne informacije',
  'Cancel': 'Odustani',
  'Update Fault': 'Ažuriraj Kvar',
  'Submitting...': 'Šalje se...',
  
  // Table headers
  'Fault ID': 'ID Kvara',
  'Due Date': 'Rok',
  
  // Messages
  'Success': 'Uspjeh',
  'Error': 'Greška',
  'Fault reported successfully': 'Kvar je uspješno prijavljen',
  'Fault updated successfully': 'Kvar je uspješno ažuriran',
  'Failed to report fault': 'Neuspješno prijavljivanje kvara',
  'Failed to update fault': 'Neuspješno ažuriranje kvara',
  'Unauthorized': 'Neovlašteno',
  'You are logged out. Logging in again...': 'Odjavljeni ste. Ponovno se prijavljujem...',
  
  // Date formatting
  'Due:': 'Rok:',
  
  // Common
  'Loading...': 'Učitava...',
  'Save': 'Spremi',
  'Edit': 'Uredi',
  'Delete': 'Obriši',
  'View': 'Prikaži',
  'Back': 'Natrag',
  'Next': 'Sljedeće',
  'Previous': 'Prethodno',
  'Close': 'Zatvori',
  'Confirm': 'Potvrdi',
  'Yes': 'Da',
  'No': 'Ne'
};

// Function to get translated text
export function t(key: string): string {
  return translations[key as keyof typeof translations] || key;
}

// Function to check if Croatian language is enabled
export function isCroatianEnabled(): boolean {
  return localStorage.getItem('language') === 'hr' || 
         localStorage.getItem('language') === null; // Default to Croatian
}

// Function to toggle language
export function toggleLanguage(): void {
  const currentLang = localStorage.getItem('language');
  const newLang = currentLang === 'hr' ? 'en' : 'hr';
  localStorage.setItem('language', newLang);
  window.location.reload();
}

// Function to get current language
export function getCurrentLanguage(): string {
  return localStorage.getItem('language') || 'hr';
}